`timescale 1ns/1ps
// Global Test Controller v2 - 2-mode Joint-Scan Controller
// State machine: Qt (test/load-unload) <-> Qf (functional/capture)
// Generates: SSE (serial scan enable), row_shift, row_load,
//            col_addr, cluster_sel, capture_en, fault aggregation
module gtc_v2 #(
    parameter TIERS        = 4,
    parameter ROWS         = 8,
    parameter COLS         = 32,
    parameter NUM_CLUSTERS = 2,
    parameter NUM_CHAINS   = 4,
    parameter MISR_W       = 32
)(
    input  wire                          scan_clk,
    input  wire                          reset_n,
    input  wire                          test_enable, // test_mode pin (1 pin)
    input  wire [NUM_CHAINS-1:0]         scan_in,     // parallel scan input
    // Output control signals (to all tiers)
    output reg                           sse,         // serial scan enable
    output reg                           row_shift,   // advance PRAS row
    output reg                           row_load,    // reset PRAS row
    output reg                           write_en,    // PRAS write strobe
    output reg  [$clog2(COLS)-1:0]       col_addr,    // PRAS column address
    output reg  [$clog2(NUM_CLUSTERS)-1:0] cluster_sel,// MSS cluster select
    output reg  [$clog2(TIERS)-1:0]      tier_sel,    // active tier
    output reg                           capture_en,  // response capture
    output wire [NUM_CHAINS-1:0]         scan_in_out, // broadcast scan_in
    // MISR inputs from each tier
    input  wire [MISR_W-1:0] misr_t0,misr_t1,misr_t2,misr_t3,
    // Fault outputs
    output reg  [MISR_W-1:0]             fault_signature,
    output reg                           fault_flag
);
    // 2-mode FSM
    localparam Qt = 1'b0; // test mode: load/unload
    localparam Qf = 1'b1; // functional mode: capture

    reg state;
    reg [7:0]  cycle_cnt;   // counts shift cycles within a pattern
    reg [7:0]  maxcycle;    // pattern load time (aligned per Tudu paper)
    reg [3:0]  row_cnt;     // track PRAS row traversal
    reg [5:0]  col_cnt;     // track PRAS column traversal

    assign scan_in_out = scan_in;

    // maxcycle = max(MSS_chain_len, PRAS_rows*cols_per_row)
    // Here: MSS=32 shifts, PRAS=8 rows * 1 write/col = 32 cycles
    localparam MAXCYCLE = 8'd32;

    always @(posedge scan_clk) begin
        if (!reset_n) begin
            state       <= Qt;
            sse         <= 1'b0;
            row_shift   <= 1'b0;
            row_load    <= 1'b1;
            write_en    <= 1'b0;
            col_addr    <= 0;
            cluster_sel <= 0;
            tier_sel    <= 0;
            capture_en  <= 1'b0;
            cycle_cnt   <= 8'd0;
            row_cnt     <= 4'd0;
            col_cnt     <= 6'd0;
            fault_signature <= 0;
            fault_flag  <= 1'b0;
            maxcycle    <= MAXCYCLE;
        end else begin
            row_load    <= 1'b0; // default
            capture_en  <= 1'b0;
            row_shift   <= 1'b0;
            write_en    <= 1'b0;

            case (state)
                Qt: begin // Test mode: simultaneously load MSS + PRAS
                    if (test_enable) begin
                        sse      <= 1'b1;        // MSS shifting
                        write_en <= 1'b1;        // PRAS writing
                        cycle_cnt <= cycle_cnt + 1'b1;

                        // PRAS: advance column each cycle
                        if (col_cnt < COLS-1) begin
                            col_addr <= col_addr + 1'b1;
                            col_cnt  <= col_cnt + 1'b1;
                        end else begin
                            // Column done: advance row
                            col_addr  <= 0;
                            col_cnt   <= 0;
                            row_shift <= 1'b1;
                            row_cnt   <= row_cnt + 1'b1;
                        end

                        // When maxcycle reached: switch to capture
                        if (cycle_cnt >= maxcycle - 1) begin
                            cycle_cnt <= 8'd0;
                            state     <= Qf;
                            sse       <= 1'b0;
                            write_en  <= 1'b0;
                        end
                    end
                end

                Qf: begin // Functional/capture: sample response
                    capture_en <= 1'b1;
                    sse        <= 1'b0;

                    // Aggregate MISR from all tiers
                    fault_signature <= misr_t0 ^ misr_t1 ^ misr_t2 ^ misr_t3;
                    fault_flag <= (misr_t0 != 0) || (misr_t1 != 0) ||
                                  (misr_t2 != 0) || (misr_t3 != 0);

                    // Advance tier and cluster for next pattern
                    if (cluster_sel == NUM_CLUSTERS-1) begin
                        cluster_sel <= 0;
                        if (tier_sel == TIERS-1) begin
                            tier_sel <= 0;
                            row_load <= 1'b1; // reset PRAS rows
                            row_cnt  <= 0;
                            col_cnt  <= 0;
                            col_addr <= 0;
                        end else
                            tier_sel <= tier_sel + 1'b1;
                    end else
                        cluster_sel <= cluster_sel + 1'b1;

                    // Return to test mode
                    state <= Qt;
                end
            endcase
        end
    end

endmodule