`timescale 1ns/1ps
module jscan_top_v2 #(
    parameter TIERS=4,parameter ROWS=8,parameter COLS=32,
    parameter NUM_CLUSTERS=2,parameter NUM_CHAINS=4,
    parameter CHAIN_LEN=32,parameter MISR_W=32
)(
    input  wire                    scan_clk,
    input  wire                    reset_n,
    input  wire [NUM_CHAINS-1:0]   scan_in,
    input  wire                    test_enable,
    output wire                    fault_flag,
    output wire [MISR_W-1:0]       fault_signature
);
    wire                              sse,row_shift,row_load,write_en,capture_en;
    wire [4:0]                        col_addr;
    wire [0:0]                        cluster_sel;
    wire [1:0]                        tier_sel;
    wire [NUM_CHAINS-1:0]             scan_in_bcast;
    wire [MISR_W-1:0] misr0,misr1,misr2,misr3;

    gtc_v2 #(.TIERS(4),.ROWS(8),.COLS(32),.NUM_CLUSTERS(2),.NUM_CHAINS(4),.MISR_W(32)) u_gtc (
        .scan_clk(scan_clk),.reset_n(reset_n),.test_enable(test_enable),
        .scan_in(scan_in),.sse(sse),.row_shift(row_shift),.row_load(row_load),
        .write_en(write_en),.col_addr(col_addr),.cluster_sel(cluster_sel),
        .tier_sel(tier_sel),.capture_en(capture_en),.scan_in_out(scan_in_bcast),
        .misr_t0(misr0),.misr_t1(misr1),.misr_t2(misr2),.misr_t3(misr3),
        .fault_signature(fault_signature),.fault_flag(fault_flag)
    );

    tier_v2 #(.TIER_ID(2'b00),.ROWS(8),.COLS(32),.NUM_CLUSTERS(2),.NUM_CHAINS(4),.CHAIN_LEN(32),.MISR_W(32)) T0(
        .scan_clk(scan_clk),.reset_n(reset_n),.tier_sel(tier_sel),.sse(sse),
        .row_shift(row_shift),.row_load(row_load),.write_en(write_en),
        .col_addr(col_addr),.cluster_sel(cluster_sel),.capture_en(capture_en),
        .scan_in(scan_in_bcast),.misr_out(misr0));

    tier_v2 #(.TIER_ID(2'b01),.ROWS(8),.COLS(32),.NUM_CLUSTERS(2),.NUM_CHAINS(4),.CHAIN_LEN(32),.MISR_W(32)) T1(
        .scan_clk(scan_clk),.reset_n(reset_n),.tier_sel(tier_sel),.sse(sse),
        .row_shift(row_shift),.row_load(row_load),.write_en(write_en),
        .col_addr(col_addr),.cluster_sel(cluster_sel),.capture_en(capture_en),
        .scan_in(scan_in_bcast),.misr_out(misr1));

    tier_v2 #(.TIER_ID(2'b10),.ROWS(8),.COLS(32),.NUM_CLUSTERS(2),.NUM_CHAINS(4),.CHAIN_LEN(32),.MISR_W(32)) T2(
        .scan_clk(scan_clk),.reset_n(reset_n),.tier_sel(tier_sel),.sse(sse),
        .row_shift(row_shift),.row_load(row_load),.write_en(write_en),
        .col_addr(col_addr),.cluster_sel(cluster_sel),.capture_en(capture_en),
        .scan_in(scan_in_bcast),.misr_out(misr2));

    tier_v2 #(.TIER_ID(2'b11),.ROWS(8),.COLS(32),.NUM_CLUSTERS(2),.NUM_CHAINS(4),.CHAIN_LEN(32),.MISR_W(32)) T3(
        .scan_clk(scan_clk),.reset_n(reset_n),.tier_sel(tier_sel),.sse(sse),
        .row_shift(row_shift),.row_load(row_load),.write_en(write_en),
        .col_addr(col_addr),.cluster_sel(cluster_sel),.capture_en(capture_en),
        .scan_in(scan_in_bcast),.misr_out(misr3));

endmodule