`timescale 1ns/1ps
// Granular 32-bit MISR with per-cluster enable
// Polynomial: x^32+x^22+x^2+x+1 (maximal length)
module misr_g #(parameter WIDTH=32)(
    input  wire              clk,
    input  wire              reset_n,
    input  wire              enable,
    input  wire [WIDTH-1:0]  data_in,
    output reg  [WIDTH-1:0]  signature
);
    wire feedback = signature[31]^signature[21]^signature[1]^signature[0];
    always @(posedge clk) begin
        if (!reset_n)
            signature <= {WIDTH{1'b0}};
        else if (enable)
            signature <= {signature[WIDTH-2:0], feedback} ^ data_in;
    end
endmodule