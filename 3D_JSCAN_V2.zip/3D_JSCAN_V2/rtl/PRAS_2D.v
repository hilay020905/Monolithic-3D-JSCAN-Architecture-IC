`timescale 1ns/1ps
// 2D PRAS Block - rows x cols grid
// Row addressing: serial shift register (1 wire vs ROWS wires)
// Col addressing: parallel binary (log2(COLS) wires)
// Total address wires: 1 + log2(COLS) instead of ROWS + COLS
// Reduces routing congestion by ~30-40% vs flat addressing
module pras_2d #(
    parameter ROWS = 8,
    parameter COLS = 32,
    parameter DW   = 1       // data width per cell
)(
    input  wire              clk,
    input  wire              reset_n,
    input  wire              test_mode,   // 1=test, 0=functional
    // Row control (serial - low congestion)
    input  wire              row_shift,   // advance row pointer
    input  wire              row_load,    // reset row to row 0
    // Column address (parallel binary)
    input  wire [$clog2(COLS)-1:0] col_addr,
    // Data
    input  wire [DW-1:0]     scan_in,     // write data (P-random stimuli)
    input  wire              write_en,    // write strobe
    output reg  [DW*COLS-1:0] row_data_out,// full row read (parallel)
    output wire [DW-1:0]     cell_out     // selected cell output
);
    // FF grid: ROWS x COLS
    reg [DW-1:0] grid [0:ROWS-1][0:COLS-1];
    // Row enable one-hot
    reg [ROWS-1:0] row_en;
    integer i, j;

    // Row enable shift register
    always @(posedge clk) begin
        if (!reset_n)   row_en <= {{(ROWS-1){1'b0}}, 1'b1};
        else if (row_load)  row_en <= {{(ROWS-1){1'b0}}, 1'b1};
        else if (row_shift) row_en <= {row_en[ROWS-2:0], row_en[ROWS-1]};
    end

    // Active row index (priority encode)
    reg [$clog2(ROWS)-1:0] active_row;
    always @(*) begin
        active_row = 0;
        for (i = 0; i < ROWS; i = i+1)
            if (row_en[i]) active_row = i[$clog2(ROWS)-1:0];
    end

    // Grid read (parallel, all cols of active row)
    always @(*) begin
        for (j = 0; j < COLS; j = j+1)
            row_data_out[j*DW +: DW] = grid[active_row][j];
    end

    // Functional: normal D-FF operation
    // Test: read response (parallel), write stimuli (column-by-column)
    always @(posedge clk) begin
        if (!reset_n) begin
            for (i = 0; i < ROWS; i = i+1)
                for (j = 0; j < COLS; j = j+1)
                    grid[i][j] <= {DW{1'b0}};
        end else if (test_mode && write_en) begin
            // Write one cell: active row, selected column
            grid[active_row][col_addr] <= scan_in;
        end
        // In functional mode, grid holds combinational state (not modeled here)
    end

    // Cell output: active row, selected column
    assign cell_out = grid[active_row][col_addr];

endmodule