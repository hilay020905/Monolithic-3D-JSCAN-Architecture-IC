`timescale 1ns/1ps
// Clustered MSS: NUM_CHAINS parallel scan chains per cluster
// NUM_CLUSTERS clusters total
// FFs partitioned into clusters by congestion proximity
// Reduces routing: each chain only fans within local cluster area
module mss_cluster #(
    parameter NUM_CLUSTERS = 2,
    parameter NUM_CHAINS   = 4,   // parallel chains per cluster
    parameter CHAIN_LEN    = 32   // FFs per chain
)(
    input  wire                              clk,
    input  wire                              reset_n,
    input  wire                              shift_en,    // SSE
    input  wire [$clog2(NUM_CLUSTERS)-1:0]   cluster_sel, // active cluster
    input  wire [NUM_CHAINS-1:0]             scan_in,     // parallel scan in
    output wire [NUM_CHAINS-1:0]             scan_out     // parallel scan out
);
    // CHAIN_LEN-deep shift registers, NUM_CHAINS wide, NUM_CLUSTERS clusters
    reg [CHAIN_LEN-1:0] chains [0:NUM_CLUSTERS-1][0:NUM_CHAINS-1];
    integer c, ch;

    genvar gc, gch;
    generate
        for (gc = 0; gc < NUM_CLUSTERS; gc = gc+1) begin : GEN_CLUSTER
            for (gch = 0; gch < NUM_CHAINS; gch = gch+1) begin : GEN_CHAIN
                always @(posedge clk) begin
                    if (!reset_n)
                        chains[gc][gch] <= {CHAIN_LEN{1'b0}};
                    else if (shift_en && (cluster_sel == gc[$clog2(NUM_CLUSTERS)-1:0]))
                        chains[gc][gch] <= {chains[gc][gch][CHAIN_LEN-2:0], scan_in[gch]};
                end
            end
        end
    endgenerate

    // scan_out taps MSB of each chain in active cluster
    genvar gso;
    generate
        for (gso = 0; gso < NUM_CHAINS; gso = gso+1) begin : GEN_SOUT
            assign scan_out[gso] = chains[cluster_sel][gso][CHAIN_LEN-1];
        end
    endgenerate

endmodule