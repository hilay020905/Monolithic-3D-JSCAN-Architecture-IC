`timescale 1ns/1ps
module row_en_sr #(parameter ROWS=8)(
    input  wire              clk,
    input  wire              reset_n,
    input  wire              shift_en,
    input  wire              row_load,
    output reg  [ROWS-1:0]   row_enable
);
    always @(posedge clk) begin
        if (!reset_n)       row_enable <= {{(ROWS-1){1'b0}}, 1'b1};
        else if (row_load)  row_enable <= {{(ROWS-1){1'b0}}, 1'b1};
        else if (shift_en)  row_enable <= {row_enable[ROWS-2:0], row_enable[ROWS-1]};
    end
endmodule
