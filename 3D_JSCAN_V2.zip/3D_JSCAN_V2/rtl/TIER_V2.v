`timescale 1ns/1ps
// Joint-Scan Tier Block v2
// P-serial = MSS_CLUSTER (clustered parallel scan chains)
// P-random = PRAS_2D (2D grid: row-shift + col-addr)
// Both operate simultaneously in test mode (Tudu paper, Sect 3.4)
// Separate MISR per mode for granular fault isolation
module tier_v2 #(
    parameter TIER_ID      = 2'b00,
    parameter ROWS         = 8,
    parameter COLS         = 32,
    parameter NUM_CLUSTERS = 2,
    parameter NUM_CHAINS   = 4,
    parameter CHAIN_LEN    = 32,
    parameter MISR_W       = 32
)(
    input  wire                              scan_clk,
    input  wire                              reset_n,
    input  wire [1:0]                        tier_sel,
    // Joint control signals
    input  wire                              sse,         // serial scan enable
    input  wire                              row_shift,
    input  wire                              row_load,
    input  wire                              write_en,
    input  wire [$clog2(COLS)-1:0]           col_addr,
    input  wire [$clog2(NUM_CLUSTERS)-1:0]   cluster_sel,
    input  wire                              capture_en,
    // Scan data
    input  wire [NUM_CHAINS-1:0]             scan_in,
    // Outputs
    output wire [MISR_W-1:0]                 misr_out   // combined signature
);
    wire active = (tier_sel == TIER_ID);

    // P-serial: MSS Cluster
    wire [NUM_CHAINS-1:0] mss_scan_out;
    mss_cluster #(
        .NUM_CLUSTERS(NUM_CLUSTERS),
        .NUM_CHAINS(NUM_CHAINS),
        .CHAIN_LEN(CHAIN_LEN)
    ) u_mss (
        .clk        (scan_clk),
        .reset_n    (reset_n),
        .shift_en   (active & sse),
        .cluster_sel(cluster_sel),
        .scan_in    (scan_in),
        .scan_out   (mss_scan_out)
    );

    // P-random: PRAS 2D grid
    wire [COLS-1:0] pras_row_out;   // parallel row read
    wire            pras_cell_out;  // single cell output
    pras_2d #(
        .ROWS(ROWS),
        .COLS(COLS),
        .DW(1)
    ) u_pras (
        .clk        (scan_clk),
        .reset_n    (reset_n),
        .test_mode  (active),
        .row_shift  (active & row_shift),
        .row_load   (active & row_load),
        .col_addr   (col_addr),
        .scan_in    (scan_in[0]),
        .write_en   (active & write_en),
        .row_data_out(pras_row_out),
        .cell_out   (pras_cell_out)
    );

    // Granular MISR for MSS response (32-bit)
    wire [MISR_W-1:0] misr_mss_sig;
    wire [MISR_W-1:0] mss_data_wide = {{(MISR_W-NUM_CHAINS){1'b0}}, mss_scan_out};
    misr_g #(.WIDTH(MISR_W)) u_misr_mss (
        .clk       (scan_clk),
        .reset_n   (reset_n),
        .enable    (active & capture_en),
        .data_in   (mss_data_wide),
        .signature (misr_mss_sig)
    );

    // Granular MISR for PRAS response (32-bit, uses full row)
    wire [MISR_W-1:0] misr_pras_sig;
    wire [MISR_W-1:0] pras_data_wide = {{(MISR_W-COLS){1'b0}}, pras_row_out};
    misr_g #(.WIDTH(MISR_W)) u_misr_pras (
        .clk       (scan_clk),
        .reset_n   (reset_n),
        .enable    (active & capture_en),
        .data_in   (pras_data_wide),
        .signature (misr_pras_sig)
    );

    // Combined signature: XOR of both MISRs
    assign misr_out = misr_mss_sig ^ misr_pras_sig;

endmodule