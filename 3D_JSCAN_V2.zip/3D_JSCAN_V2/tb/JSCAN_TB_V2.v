`timescale 1ns/1ps
module tb_jscan_v2;
    localparam NUM_CHAINS = 4;
    localparam MISR_W     = 32;
    localparam TIERS      = 4;

    reg                    scan_clk;
    reg                    reset_n;
    reg  [NUM_CHAINS-1:0]  scan_in;
    reg                    test_enable;
    wire                   fault_flag;
    wire [MISR_W-1:0]      fault_signature;

    jscan_top_v2 #(
        .TIERS(4),.ROWS(8),.COLS(32),
        .NUM_CLUSTERS(2),.NUM_CHAINS(4),
        .CHAIN_LEN(32),.MISR_W(32)
    ) dut (
        .scan_clk(scan_clk),.reset_n(reset_n),
        .scan_in(scan_in),.test_enable(test_enable),
        .fault_flag(fault_flag),.fault_signature(fault_signature)
    );

    initial begin scan_clk=0; forever #5 scan_clk=~scan_clk; end

    initial begin
        $dumpfile("jscan_v2_tb.vcd");
        $dumpvars(0, tb_jscan_v2);
        reset_n=1; scan_in=4'b0000; test_enable=0;
        $display("=== 3D Joint-Scan V2 Verification ===");

        // Case 1: Async reset
        $display("[%0t] Case1: Async Reset", $time);
        #7 reset_n=0; #10 reset_n=1;

        // Case 2: Joint-scan - MSS+PRAS simultaneous
        $display("[%0t] Case2: Joint-Scan (MSS+PRAS simultaneous)", $time);
        test_enable=1;
        repeat(200) begin @(negedge scan_clk); scan_in=$random; end

        // Case 3: Freeze
        $display("[%0t] Case3: Freeze test_enable=0", $time);
        @(negedge scan_clk); test_enable=0; #40;

        // Case 4: All-1 scan in (MSS chain fill)
        $display("[%0t] Case4: All-1 scan pattern (MSS chain fill)", $time);
        test_enable=1; scan_in=4'b1111;
        repeat(100) @(negedge scan_clk);

        // Case 5: Alternating pattern (toggle power test)
        $display("[%0t] Case5: Alternating 1010 (toggle power)", $time);
        scan_in=4'b0000;
        repeat(64) begin @(negedge scan_clk); scan_in=~scan_in; end

        // Case 6: Mid-operation reset
        $display("[%0t] Case6: Mid-op async reset", $time);
        #3 reset_n=0; #5 reset_n=1; #20;

        // Case 7: Full cycle - all tiers, all clusters
        $display("[%0t] Case7: Full 4-tier 2-cluster sweep", $time);
        test_enable=1; scan_in=$random;
        repeat(512) @(negedge scan_clk);

        $display("[%0t] fault_flag=%b signature=%h", $time, fault_flag, fault_signature);
        $display("=== Verification Complete ===");
        $finish;
    end
endmodule