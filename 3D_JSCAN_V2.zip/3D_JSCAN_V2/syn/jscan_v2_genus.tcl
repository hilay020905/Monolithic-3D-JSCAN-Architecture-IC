# 3D Joint-Scan V2 - Genus Synthesis
set_db init_lib_search_path {
  ../libs/faraday
  ../libs/cadsl
}

read_libs {
  ../libs/faraday/fse0k_d_generic_core_ff1p32v125c.lib
  ../libs/cadsl/cadsl_ffcell_lib_updated.lib
}

# Block Faraday FFs - use PRAS CADSL cells only
set_dont_use [get_lib_cells fse0k_d_generic_core_ff1p32v125c/* -filter "is_sequential==true"]

# Read RTL - leaf modules first
read_hdl {
  ../rtl/MISR_G.v
  ../rtl/ROW_EN_SR.v
  ../rtl/PRAS_2D.v
  ../rtl/MSS_CLUSTER.v
  ../rtl/GTC_V2.v
  ../rtl/TIER_V2.v
  ../rtl/JSCAN_TOP_V2.v
}

elaborate jscan_top_v2
check_design

# Constraints - 100MHz scan clock
create_clock -name scan_clk -period 10.0 [get_ports scan_clk]
set_clock_uncertainty 0.2  [get_clocks scan_clk]
set_clock_transition  0.05 [get_clocks scan_clk]
set_input_delay  2.0 -clock scan_clk [all_inputs]
set_output_delay 2.0 -clock scan_clk [all_outputs]
set_false_path -from [get_ports reset_n]
set_load 0.05 [all_outputs]

syn_generic
syn_map
syn_opt

report_area   > reports/area.rpt
report_timing > reports/timing.rpt
report_gates  > reports/gates.rpt
report_qor    > reports/qor.rpt

write_hdl  > outputs/jscan_v2_syn.v
write_sdc  > outputs/jscan_v2_syn.sdc
write_db     outputs/jscan_v2_genus.db
puts "=== V2 SYNTHESIS DONE ===" 