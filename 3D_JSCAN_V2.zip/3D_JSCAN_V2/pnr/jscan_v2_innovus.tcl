# 3D Joint-Scan V2 - Innovus P&R
set init_verilog ../syn/outputs/jscan_v2_syn.v
set init_top_cell jscan_top_v2
set init_lef_file {../libs/lef/header6m00015_V55.lef ../libs/lef/fse0k_d_generic_core.lef}

create_library_set -name jscan_libs -timing {
  ../libs/faraday/fse0k_d_generic_core_ff1p32v125c.lib
  ../libs/cadsl/cadsl_ffcell_lib_updated.lib
}
create_delay_corner    -name dc_typ -library_set jscan_libs
create_constraint_mode -name cm1 -sdc_files {../syn/outputs/jscan_v2_syn.sdc}
create_analysis_view   -name av_typ -constraint_mode cm1 -delay_corner dc_typ
init_design

set_analysis_view -setup av_typ -hold av_typ
floorPlan -s 200 200 10 10 10 10
place_design
ccopt_design
routeDesign
saveNetlist outputs/jscan_v2_final.v
saveDesign  outputs/jscan_v2_final.enc
puts "=== V2 P&R DONE ===" 